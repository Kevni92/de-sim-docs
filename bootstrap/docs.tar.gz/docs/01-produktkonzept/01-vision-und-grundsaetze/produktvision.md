---
title: 1.1 Produktvision
summary: Teilkapitel zu Vision und Grundsätze – 1.1 Produktvision.
status: Arbeitsstand 0.3
last_updated: 2026-07-13
---

# 1.1 Produktvision

Der Deutschland-Simulator übersetzt komplexe politische Eingriffe in verständliche Wirkungsketten. Ein Nutzer kann beispielsweise den Grundfreibetrag erhöhen, Kita-Ausgaben verändern oder die elektronische Arbeitsunfähigkeitsbescheinigung abschaffen. Das System zeigt anschließend nicht nur die unmittelbaren Kosten, sondern auch plausible Folgepfade.

Beispiel Kita:

`mehr Finanzierung → mehr Personal bzw. geringere Überlastung → verlässlichere Öffnungszeiten → weniger Betreuungsnotfälle → weniger verlorene Arbeitsstunden der Eltern → höhere Arbeitsmarktteilnahme und geringere Belastung`

Beispiel Schule:

`Investition → bessere Ausstattung bzw. Lernbedingungen → mögliche Kompetenzgewinne → langfristig höhere Erwerbschancen, Steuereinnahmen und gesellschaftliche Teilhabe`

## Navigation

- [Zur Kapitelübersicht](index.md)
- [Anforderungskatalog](../03-anforderungskatalog/index.md)
- [UI und Interaktionsmodell](../04-ui-und-interaktionsmodell/index.md)
- [Validierung, Governance und Ethik](../../09-governance/19-validierung-governance-und-ethik/index.md)
