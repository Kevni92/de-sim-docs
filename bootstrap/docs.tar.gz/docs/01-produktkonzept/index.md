---
title: Produktkonzept
summary: Übersicht der Kapitel in diesem Dokumentationsbereich.
status: Arbeitsstand 0.3
last_updated: 2026-07-13
---

# Produktkonzept

- [1. Vision und Grundsätze](01-vision-und-grundsaetze/index.md)
- [3. Anforderungskatalog](03-anforderungskatalog/index.md)
- [4. UI und Interaktionsmodell](04-ui-und-interaktionsmodell/index.md)

