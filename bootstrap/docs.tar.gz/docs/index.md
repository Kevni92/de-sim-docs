---
title: Deutschland-Simulator
summary: Einstieg in Pflichtenheft, Research Briefing, Datenmodell und technische Planung.
status: Arbeitsstand 0.3
last_updated: 2026-07-13
---

# Deutschland-Simulator

## Transparenter Staatshaushalts- und Wirkungssimulator

Der Deutschland-Simulator soll politische Änderungen als nachvollziehbare **Wenn-Dann-Szenarien** darstellen. Neben Einnahmen und Ausgaben werden Verteilung, Zeit, Gesundheit, Bildung, Demografie, regionale Lebensbedingungen und langfristige Folgewirkungen sichtbar gemacht.

> **Leitprinzip:** Jede sichtbare Wirkung muss bis zu Quelle, Formel, Annahme, Datenstand und Modellversion zurückverfolgt werden können. Wo keine belastbare Quantifizierung möglich ist, zeigt das System einen qualitativen Wirkungspfad statt einer erfundenen Zahl.

## Schnelleinstieg

- [Vision und Grundsätze](01-produktkonzept/01-vision-und-grundsaetze/index.md)
- [Anforderungskatalog](01-produktkonzept/03-anforderungskatalog/index.md)
- [Einnahmen und Steuern](02-fiskalmodell/05-einnahmen-und-steuern/index.md)
- [Ausgaben und Leistungen](02-fiskalmodell/06-ausgaben-und-leistungen/index.md)
- [Wirkungsmodell](04-wirkungsmodellierung/08-wirkungsmodell/index.md)
- [Evidenzdatenbank](06-evidenz-transparenz/14-evidenzdatenbank-und-quellenprovenienz/index.md)
- [Technische Architektur](08-technik/18-technische-architektur/index.md)
- [MVP und Roadmap](10-umsetzung/20-mvp-und-roadmap/index.md)
- [KI-Leseindex](00-meta/ki-leseindex.md)

## Dokumenttypen

Diese Dokumentation dient gleichzeitig als:

1. Pflichtenheft und Anforderungskatalog,
2. Research Briefing,
3. Daten- und Evidenzkonzept,
4. Modellierungs- und Architekturplan,
5. Governance- und Transparenzkonzept,
6. Designbriefing für Figma.

## Status

**Version:** 0.3  
**Stand:** 13. Juli 2026  
**Charakter:** Planungs- und Forschungsdokumentation; noch keine produktive Modellimplementierung.
