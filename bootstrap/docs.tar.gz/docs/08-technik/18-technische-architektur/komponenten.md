---
title: 18.1 Komponenten
summary: Teilkapitel zu Technische Architektur – 18.1 Komponenten.
status: Arbeitsstand 0.3
last_updated: 2026-07-13
---

# 18.1 Komponenten

1. Web-Frontend,
2. Szenario- und Benutzerprofilservice,
3. statische Mikrosimulationsengine,
4. dynamische Wirkungsengine,
5. Demografieengine,
6. Evidenz- und Provenienzdatenbank,
7. Datenpipeline und Versionierung,
8. Export- und Reproduzierbarkeitsservice.

## Navigation

- [Zur Kapitelübersicht](index.md)
- [Synthetische Bevölkerung und Haushalte](../../03-bevoelkerung-daten/07-synthetische-bevoelkerung-und-haushalte/index.md)
- [Evidenzdatenbank und Quellenprovenienz](../../06-evidenz-transparenz/14-evidenzdatenbank-und-quellenprovenienz/index.md)
- [Validierung, Governance und Ethik](../../09-governance/19-validierung-governance-und-ethik/index.md)
