---
title: 18.3 Datenhaltung
summary: Teilkapitel zu Technische Architektur – 18.3 Datenhaltung.
status: Arbeitsstand 0.3
last_updated: 2026-07-13
---

# 18.3 Datenhaltung

Empfohlene Trennung:

- relationale Metadatenbank,
- versionierter Objektspeicher für Rohdaten und Exporte,
- analytische Spaltenformate für Modellhaushalte,
- Graphdarstellung für Wirkungsketten,
- unveränderliches Laufprotokoll.

## Navigation

- [Zur Kapitelübersicht](index.md)
- [Synthetische Bevölkerung und Haushalte](../../03-bevoelkerung-daten/07-synthetische-bevoelkerung-und-haushalte/index.md)
- [Evidenzdatenbank und Quellenprovenienz](../../06-evidenz-transparenz/14-evidenzdatenbank-und-quellenprovenienz/index.md)
- [Validierung, Governance und Ethik](../../09-governance/19-validierung-governance-und-ethik/index.md)
