---
title: 18. Technische Architektur
summary: Kapitelübersicht zu Technische Architektur.
status: Arbeitsstand 0.3
last_updated: 2026-07-13
---

# 18. Technische Architektur

Dieses Kapitel definiert die fachlichen und technischen Anforderungen dieses Themenbereichs.

## Unterkapitel

- [18.1 Komponenten](komponenten.md)
- [18.2 Rechenkern](rechenkern.md)
- [18.3 Datenhaltung](datenhaltung.md)
- [18.4 Versionierung](versionierung.md)
- [18.5 Berechnungsmodus](berechnungsmodus.md)
- [18.6 API](api.md)
- [18.7 Testbarkeit](testbarkeit.md)

## Verwandte Kapitel

- [Synthetische Bevölkerung und Haushalte](../../03-bevoelkerung-daten/07-synthetische-bevoelkerung-und-haushalte/index.md)
- [Evidenzdatenbank und Quellenprovenienz](../../06-evidenz-transparenz/14-evidenzdatenbank-und-quellenprovenienz/index.md)
- [Validierung, Governance und Ethik](../../09-governance/19-validierung-governance-und-ethik/index.md)
