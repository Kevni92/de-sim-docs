---
title: 18.4 Versionierung
summary: Teilkapitel zu Technische Architektur – 18.4 Versionierung.
status: Arbeitsstand 0.3
last_updated: 2026-07-13
---

# 18.4 Versionierung

Jeder Lauf referenziert:

- Szenarioversion,
- Regelversion,
- Datenversion,
- Parameterversion,
- Code-Commit,
- Zufallsseed bei stochastischen Läufen.

## Navigation

- [Zur Kapitelübersicht](index.md)
- [Synthetische Bevölkerung und Haushalte](../../03-bevoelkerung-daten/07-synthetische-bevoelkerung-und-haushalte/index.md)
- [Evidenzdatenbank und Quellenprovenienz](../../06-evidenz-transparenz/14-evidenzdatenbank-und-quellenprovenienz/index.md)
- [Validierung, Governance und Ethik](../../09-governance/19-validierung-governance-und-ethik/index.md)
