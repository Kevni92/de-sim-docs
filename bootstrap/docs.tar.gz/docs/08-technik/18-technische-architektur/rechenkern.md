---
title: 18.2 Rechenkern
summary: Teilkapitel zu Technische Architektur – 18.2 Rechenkern.
status: Arbeitsstand 0.3
last_updated: 2026-07-13
---

# 18.2 Rechenkern

Für Steuer- und Transferregeln sind regelbasierte, testbare Modelle erforderlich. OpenFisca oder GETTSIM können geprüft werden. EUROMOD ist ein wichtiger methodischer Referenzpunkt für statische Steuer- und Transfersimulationen. Dynamische Verhaltens- und Demografiemodule bleiben getrennt, damit statische und spekulativere Ergebnisse nicht vermischt werden.

## Navigation

- [Zur Kapitelübersicht](index.md)
- [Synthetische Bevölkerung und Haushalte](../../03-bevoelkerung-daten/07-synthetische-bevoelkerung-und-haushalte/index.md)
- [Evidenzdatenbank und Quellenprovenienz](../../06-evidenz-transparenz/14-evidenzdatenbank-und-quellenprovenienz/index.md)
- [Validierung, Governance und Ethik](../../09-governance/19-validierung-governance-und-ethik/index.md)
