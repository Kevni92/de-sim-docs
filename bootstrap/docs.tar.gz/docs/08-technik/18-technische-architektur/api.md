---
title: 18.6 API
summary: Teilkapitel zu Technische Architektur – 18.6 API.
status: Arbeitsstand 0.3
last_updated: 2026-07-13
---

# 18.6 API

Die interne API liefert nicht nur Ergebniswerte, sondern auch Metadaten:

- Einheit,
- Preisjahr,
- staatliche Ebene,
- Quellen-IDs,
- Unsicherheitsstatus,
- Rechenbaum-ID.

## Navigation

- [Zur Kapitelübersicht](index.md)
- [Synthetische Bevölkerung und Haushalte](../../03-bevoelkerung-daten/07-synthetische-bevoelkerung-und-haushalte/index.md)
- [Evidenzdatenbank und Quellenprovenienz](../../06-evidenz-transparenz/14-evidenzdatenbank-und-quellenprovenienz/index.md)
- [Validierung, Governance und Ethik](../../09-governance/19-validierung-governance-und-ethik/index.md)
