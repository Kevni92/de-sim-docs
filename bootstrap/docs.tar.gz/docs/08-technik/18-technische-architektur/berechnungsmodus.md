---
title: 18.5 Berechnungsmodus
summary: Teilkapitel zu Technische Architektur – 18.5 Berechnungsmodus.
status: Arbeitsstand 0.3
last_updated: 2026-07-13
---

# 18.5 Berechnungsmodus

- schnelle Live-Vorschau mit aggregierten Elastizitäten,
- präziser statischer Modelllauf im Hintergrund,
- optionaler Langfristszenariolauf,
- Vergleich der Unterschiede zwischen den Stufen.

## Navigation

- [Zur Kapitelübersicht](index.md)
- [Synthetische Bevölkerung und Haushalte](../../03-bevoelkerung-daten/07-synthetische-bevoelkerung-und-haushalte/index.md)
- [Evidenzdatenbank und Quellenprovenienz](../../06-evidenz-transparenz/14-evidenzdatenbank-und-quellenprovenienz/index.md)
- [Validierung, Governance und Ethik](../../09-governance/19-validierung-governance-und-ethik/index.md)
