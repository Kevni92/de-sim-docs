---
title: Vertrag eines Simulationsmoduls
summary: Einheitliche Schnittstelle für Eingaben, Ausgaben, Evidenz, Unsicherheit und Tests eines Fachmoduls.
status: Entwurf
last_updated: 2026-07-13
---

# Vertrag eines Simulationsmoduls

Jedes fachliche Modul muss unabhängig prüfbar und austauschbar sein. Ein Modul darf Ergebnisse nur veröffentlichen, wenn sein Vertrag vollständig erfüllt ist.

## Eingaben

- Baseline-ID und Rechtsstand,
- Policy-Lever mit altem und neuem Wert,
- betroffene Population oder Aggregate,
- Zeitraum und Preisbasis,
- aktivierte Verhaltens- und Szenarioannahmen,
- Referenzen auf Daten- und Parameterversionen.

## Ausgaben

- zentrale Schätzung und Bandbreite,
- Einheit, Zeitraum und staatliche Ebene,
- betroffene Personen oder Haushalte,
- direkte, indirekte und langfristige Ergebnisse getrennt,
- Evidenzstatus je Ergebnis,
- vollständige Quellen- und Rechenbaum-IDs,
- Warnungen bei Extrapolation oder fehlenden Daten.

## Fehlerzustände

Ein Modul liefert keine Fantasiezahl. Zulässige Zustände sind:

- `not_applicable`: Maßnahme betrifft die Population nicht,
- `insufficient_data`: Datengrundlage reicht nicht,
- `unsupported_combination`: gewählte Reglerkombination ist noch nicht modelliert,
- `outside_validity_range`: Parameter werden außerhalb des belegten Bereichs verwendet,
- `calculation_failed`: technischer Fehler mit reproduzierbarer Lauf-ID.

## Tests

- Referenzfälle mit manuell geprüften Ergebnissen,
- Grenzwert- und Nulltests,
- Aggregatabgleich gegen amtliche Werte,
- Regressionstests bei Regeländerungen,
- Tests gegen doppelte Zählung,
- deterministische Wiederholbarkeit oder dokumentierter Zufallsseed.

## Verwandte Kapitel

- [Technische Architektur](18-technische-architektur/index.md)
- [Definition of Done](../10-umsetzung/20-mvp-und-roadmap/definition-of-done-fuer-ein-modul.md)
- [Evidenzdatenbank](../06-evidenz-transparenz/14-evidenzdatenbank-und-quellenprovenienz/index.md)
