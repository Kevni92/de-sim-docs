---
title: Technische Architektur
summary: Übersicht der Kapitel in diesem Dokumentationsbereich.
status: Arbeitsstand 0.3
last_updated: 2026-07-13
---

# Technische Architektur

- [18. Technische Architektur](18-technische-architektur/index.md)

