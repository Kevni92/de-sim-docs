---
title: Dokumentationsstandard
summary: Vorgaben für kleine Kapitel, Metadaten, Querverweise und KI-freundliche Struktur.
status: verbindlich
last_updated: 2026-07-13
---

# Dokumentationsstandard

## Granularität

Jede Markdown-Datei behandelt genau eine fachliche Frage. Zielgröße sind etwa 150 bis 800 Wörter. Größere Themen erhalten ein Verzeichnis mit `index.md` und mehreren Unterkapiteln.

## Pflichtbestandteile

Jede Fachdatei enthält:

- einen eindeutigen Titel,
- eine kurze `summary` im YAML-Header,
- Status und Aktualisierungsdatum,
- klare Definitionen und Abgrenzungen,
- Verweise auf direkt abhängige oder weiterführende Kapitel,
- offene Fragen, wenn Entscheidungen noch nicht getroffen wurden.

## Verweise

Interne Links sollen auf konkrete Markdown-Dateien zeigen. Ein Kapitel darf keine wesentliche Annahme nur implizit aus einem anderen Kapitel übernehmen.

## KI-Nutzung

Für token-effizientes Lesen gelten folgende Regeln:

1. Zuerst [KI-Leseindex](ki-leseindex.md) verwenden.
2. Nur das Kapitel laden, das die konkrete Frage beantwortet.
3. Abhängigkeiten über den Abschnitt „Verwandte Kapitel“ nachladen.
4. Quellenregister nicht vollständig laden, wenn eine konkrete Quellen-ID genügt.

## Benennung

- Verzeichnisse und Dateien: Kleinbuchstaben, Bindestriche, ASCII-Umschrift.
- Anforderungs-IDs: `FR-`, `TR-`, `NFR-`.
- Quellen-IDs: `SRC-`.
- Parameter-IDs: `PAR-`.
- Wirkungskanten: `EFF-`.
- Modellläufe: `RUN-`.
