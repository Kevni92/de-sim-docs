---
title: Änderungs- und Entscheidungsprozess
summary: Regeln für Dokumentationsänderungen, Reviews, offene Entscheidungen und Versionen.
status: Entwurf
last_updated: 2026-07-13
---

# Änderungs- und Entscheidungsprozess

## Änderungen

Jede Änderung soll in einem thematisch begrenzten Commit erfolgen. Der Commit beschreibt, ob Anforderungen, Datenannahmen, Modelllogik oder nur Formulierungen geändert wurden.

## Fachliche Entscheidungen

Entscheidungen mit Auswirkungen auf mehrere Module werden als Architecture Decision Record dokumentiert. Ein Eintrag enthält Problem, Optionen, Entscheidung, Begründung, Risiken und betroffene Kapitel.

## Review

Änderungen an quantitativen Modellannahmen benötigen mindestens:

- fachlichen Review der Quelle,
- technischen Review der Umsetzung,
- Prüfung auf doppelte Zählung,
- Prüfung der Darstellung von Unsicherheit.

## Veraltete Inhalte

Veraltete Kapitel bleiben über Git nachvollziehbar, werden im aktuellen Stand aber eindeutig als ersetzt markiert. Quellen und Parameter erhalten Gültigkeitszeiträume statt still überschrieben zu werden.
