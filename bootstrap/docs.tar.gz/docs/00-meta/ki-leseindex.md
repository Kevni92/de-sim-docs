---
title: KI-Leseindex
summary: Token-effiziente Lesewege zu Anforderungen, Modellen, Daten, Evidenz und Umsetzung.
status: laufend gepflegt
last_updated: 2026-07-13
---

# KI-Leseindex

Diese Seite ist der bevorzugte Einstieg für KI-gestützte Recherche. Für eine konkrete Aufgabe sollen nur die hier genannten Kapitel und deren direkte Verweise geladen werden.

## Aufgabe: Produkt und UI verstehen

1. [Produktvision](../01-produktkonzept/01-vision-und-grundsaetze/produktvision.md)
2. [Funktionale Kernanforderungen](../01-produktkonzept/03-anforderungskatalog/funktionale-kernanforderungen.md)
3. [Desktop-Grundlayout](../01-produktkonzept/04-ui-und-interaktionsmodell/desktop-grundlayout.md)
4. [Berechnungstransparenz](../06-evidenz-transparenz/15-berechnungstransparenz-im-produkt/index.md)

## Aufgabe: Eine Steuer oder Ausgabe modellieren

1. [Systemgrenze und Baseline](../02-fiskalmodell/02-systemgrenze-und-baseline/index.md)
2. [Einnahmen und Steuern](../02-fiskalmodell/05-einnahmen-und-steuern/index.md) oder [Ausgaben und Leistungen](../02-fiskalmodell/06-ausgaben-und-leistungen/index.md)
3. [Synthetische Bevölkerung](../03-bevoelkerung-daten/07-synthetische-bevoelkerung-und-haushalte/index.md)
4. [Vier Wirkungsebenen](../04-wirkungsmodellierung/08-wirkungsmodell/vier-ebenen.md)
5. [Definition of Done](../10-umsetzung/20-mvp-und-roadmap/definition-of-done-fuer-ein-modul.md)

## Aufgabe: Einen indirekten Effekt ergänzen

1. [Wirkungsgraph](../04-wirkungsmodellierung/08-wirkungsmodell/wirkungsgraph.md)
2. [Nicht monetäre Wirkungen](../04-wirkungsmodellierung/09-indirekte-und-nicht-monetaere-wirkungen/index.md)
3. [Evidenzbewertung](../06-evidenz-transparenz/14-evidenzdatenbank-und-quellenprovenienz/mehrdimensionale-evidenzbewertung.md)
4. [Unsicherheit und Szenarien](../04-wirkungsmodellierung/16-unsicherheit-und-szenarien/index.md)

## Aufgabe: Quellen und Berechnung prüfen

1. [Pflichtfelder einer Quelle](../06-evidenz-transparenz/14-evidenzdatenbank-und-quellenprovenienz/pflichtfelder-einer-quelle.md)
2. [Pflichtfelder eines Parameters](../06-evidenz-transparenz/14-evidenzdatenbank-und-quellenprovenienz/pflichtfelder-eines-parameters.md)
3. [Rechenbaum](../06-evidenz-transparenz/15-berechnungstransparenz-im-produkt/rechenbaum.md)
4. [Quellenregister](../06-evidenz-transparenz/22-quellenregister/index.md)

## Aufgabe: Technisch implementieren

1. [Komponenten](../08-technik/18-technische-architektur/komponenten.md)
2. [Rechenkern](../08-technik/18-technische-architektur/rechenkern.md)
3. [Datenhaltung](../08-technik/18-technische-architektur/datenhaltung.md)
4. [API](../08-technik/18-technische-architektur/api.md)
5. [Testbarkeit](../08-technik/18-technische-architektur/testbarkeit.md)
6. [Modulvertrag](../08-technik/modulvertrag.md)

## Maschinenlesbare Orientierung

Die Datei [`/llms.txt`](../llms.txt) enthält eine kompakte Liste aller Hauptbereiche und Einstiegsdateien.
