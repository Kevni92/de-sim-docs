---
title: Einstieg und Meta
summary: Lesewege, Dokumentationsregeln, Begriffe und Änderungsprozess.
status: verbindlich für die Dokumentation
last_updated: 2026-07-13
---

# Einstieg und Meta

Dieser Bereich erklärt, wie die Dokumentation strukturiert, gelesen und fortgeschrieben wird.

## Inhalte

- [KI-Leseindex](ki-leseindex.md): kurze Lesewege für konkrete Aufgaben.
- [Dokumentationsstandard](dokumentationsstandard.md): Regeln für kleine, verlinkte Kapitel.
- [Glossar](glossar.md): zentrale Fachbegriffe.
- [Änderungs- und Entscheidungsprozess](aenderungsprozess.md): Umgang mit Versionen, Reviews und offenen Fragen.
