---
title: Glossar
summary: Verbindliche Definitionen zentraler Begriffe des Simulators.
status: Entwurf
last_updated: 2026-07-13
---

# Glossar

| Begriff | Bedeutung |
|---|---|
| Baseline | Versionierter Referenzlauf mit festem Rechts-, Daten-, Preis- und Bevölkerungsstand. |
| Policy Lever | Durch Nutzer veränderbarer politischer Parameter, etwa Steuersatz oder Ausgabenbudget. |
| Direkte Wirkung | Unmittelbare rechnerische Änderung ohne Verhaltensanpassung. |
| Indirekte Wirkung | Folge über mindestens einen vermittelnden Mechanismus, etwa Betreuungsausfall → Arbeitsausfall. |
| Langfristige Wirkung | Wirkung mit relevantem Zeitverzug, häufig über Verhalten, Demografie oder Humankapital. |
| Synthetischer Haushalt | Modellhaushalt, der eine gewichtete Gruppe realer Haushalte repräsentiert. |
| Claim | Aus einer Quelle abgeleitete, prüfbare Aussage. |
| Parameter | Quantitativer oder qualitativer Modellwert mit Quelle, Einheit, Gültigkeit und Unsicherheit. |
| Effect Edge | Gerichtete Kante im Wirkungsgraphen zwischen Ursache und Ergebnis. |
| Outcome Metric | Sichtbare Ergebniskennzahl, etwa Steueraufkommen, Krankheitstage oder Betreuungsstabilität. |
| Provenienz | Nachweis, aus welchen Daten, Annahmen, Formeln und Versionen ein Ergebnis entstanden ist. |
| Evidenzklasse | Kennzeichnung der Aussagekraft und Übertragbarkeit einer Quelle oder Wirkung. |
| Scheingenauigkeit | Darstellung einer exakten Zahl, obwohl Daten oder Modell keine entsprechende Präzision rechtfertigen. |
