---
title: Downloads
summary: Exportierte PDF-, Word- und Designbriefing-Fassungen.
status: ergänzende Exporte
last_updated: 2026-07-13
---

# Downloads

Die Markdown-Kapitel im Repository sind die primäre und aktuellste Dokumentation. Ergänzend liegen im Verzeichnis `exports/` statische Fassungen:

- [Pflichtenheft und Research Briefing als PDF](https://github.com/Kevni92/de-sim-docs/raw/main/exports/Deutschland_Simulator_Pflichtenheft_Research_Briefing_v0.2.pdf)
- [Pflichtenheft und Research Briefing als Word-Datei](https://github.com/Kevni92/de-sim-docs/raw/main/exports/Deutschland_Simulator_Pflichtenheft_Research_Briefing_v0.2.docx)
- [Figma-Prompt als Markdown](https://github.com/Kevni92/de-sim-docs/blob/main/exports/Figma_Prompt_Deutschland_Simulator_v0.2.md)

Die Exporte werden nicht automatisch aus jedem Commit neu erzeugt und können deshalb hinter den Markdown-Kapiteln zurückliegen.
